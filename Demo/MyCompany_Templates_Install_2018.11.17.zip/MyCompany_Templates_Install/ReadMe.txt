Templates Installation Instructions
-----------------------------------

Pre-requisites
==============
(1) BullZip PDF Printer
    -------------------
    See 'InstallSignature.txt' for details
    
(2) Image Magick
    ------------
    See 'InstallSignature.txt' for details

Word Templates
==============
(1) The installation archive (zip file) has to be physically extracted to a 
    non-UNC folder name, for example to 'C:\Temp\TemplatesInstall' but not 
    to '\\FileServer\Shared\TemplatesInstall'.
(2) From the extracted installation archive, as the normal logged-in user, 
    double click on 'Install.bat' to execute or right click on 'Install.bat' 
    and select 'Open' to perform the 1st step of the installation process.
(3) Right click on 'Install.bat' and select 'Run as administrator' to 
    complete the installation process.
